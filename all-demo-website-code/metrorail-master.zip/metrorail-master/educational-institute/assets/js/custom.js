const dateTime = new Date();
document.getElementById("date-time").innerHTML = dateTime;